/* sum.c */

// sum関数
// Int型の引数を2つとり、それらを足す

int sum(int min,int max)
{
    // Int型変数numを定義
	int num;
    // numに引数の値2つを足した値を代入
	num = min + max;
    // numの値を戻り値として返す！
	return num;
}
